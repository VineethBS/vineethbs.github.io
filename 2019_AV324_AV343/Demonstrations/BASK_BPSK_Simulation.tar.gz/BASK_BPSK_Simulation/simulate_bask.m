%% Simulation of a BASK system
addpath CommnSystem_Components/

%% Global system parameters
sampling_frequency = 1000; % 1 kHz
bit_time = 0.1; % 0.1 secs
num_samples_in_bit_time = sampling_frequency * bit_time;
carrier_frequency = 100; % 100 Hz

%% Generate a sequence of frames - each frame containing a header for frame recovery and timing synchronization

baseband_signal = [];
barker_sequence = [1 1 1 1 1 0 0 1 1 0 1 0 1];
header = [[1,0,1,0,1,0,1,0,1,0], barker_sequence];
generated_frames = {};

for i = 1:10
    generated_frames{i} = generate_frame_of_bits(0.5, 50, header);
    baseband_signal = [baseband_signal, generate_bask_baseband_signal_for_frame(generated_frames{i}, num_samples_in_bit_time, 1)];
    baseband_signal = [baseband_signal, generate_gap_between_frames(50, num_samples_in_bit_time)];
end

%% Modulate the signal using the carrier
modulated_signal = modulate_baseband_signal(baseband_signal, carrier_frequency, 0, sampling_frequency);

%% Simulate filtering of the signal by the channel
channel_output = pass_through_passband_channel(modulated_signal, 1, 80, 200, sampling_frequency, 100);
channel_output = add_gaussian_noise(channel_output, 0.01);

%% Receive the channel output and filter it using the front end filter
rx_filter_output = rx_frontend_filter_passband(channel_output, 1, 80, 200, sampling_frequency, 100);

%% Demodulate using non-coherent demodulation
demodulated_signal = 2 * demodulate_noncoherent_bask(rx_filter_output, bit_time, sampling_frequency);
eyediagram(demodulated_signal, num_samples_in_bit_time * 2);

%% Do matched filtering
matched_filter_output = matched_filter_rectangular(demodulated_signal, num_samples_in_bit_time);
eyediagram(matched_filter_output, num_samples_in_bit_time * 2);

%% Sample using early late sampler
[samples, sampling_times] = early_late_sampler(matched_filter_output, sampling_frequency, bit_time, floor(num_samples_in_bit_time/2), 10, 20, 0.8);

%% Detect the bits
detected_bit_stream = thresholder(samples, 0.8);

%% Recover frames
detected_frames = frame_recovery(detected_bit_stream, barker_sequence, 12, 10, 50);

% figure;
% hold on;
% plot(baseband_signal + 4, 'r');
% plot(demodulated_signal + 2, 'k');
% plot(matched_filter_output, 'b');
% stem(sampling_times, samples);
% hold off;

%% Find out whether the frames have been received correctly
for i = 1:length(generated_frames)
    if i > length(detected_frames)
        fprintf(1, '%u-th frame missed\n', i);
        continue;
    end
    if sum(generated_frames{i} == detected_frames{i}) < length(generated_frames{i})
        fprintf(1, 'Bit error in %u-th frame; %u bits in error\n', i, length(generated_frames{i}) - sum(generated_frames{i} == detected_frames{i}));
    end
end
