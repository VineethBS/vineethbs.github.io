parameters;
baseband_signal = [];
for i = 1:10
    % baseband_signal = [baseband_signal, generate_bask_baseband_signal_for_frame(generate_frame_of_bits(0.5, 10, []), num_samples_in_bit_time, 1)];
    baseband_signal = [baseband_signal, generate_bpsk_baseband_signal_for_frame(generate_frame_of_bits(0.5, 10, []), num_samples_in_bit_time, 1)];
    baseband_signal = [baseband_signal, generate_gap_between_frames(5000)];
end
modulated_signal = modulate_baseband_signal(baseband_signal, carrier_frequency, 0, sampling_frequency);
