function detected_bits = thresholder(samples, threshold)
detected_bits = 1 * (samples > threshold);

