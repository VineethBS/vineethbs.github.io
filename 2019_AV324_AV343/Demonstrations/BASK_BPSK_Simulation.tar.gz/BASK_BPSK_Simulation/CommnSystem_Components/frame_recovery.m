function detected_frames = frame_recovery(detected_bit_stream, marker_sequence, threshold, frame_start_offset_from_marker, frame_end_offset_from_marker)
actual_bit_stream = detected_bit_stream;
detected_bit_stream(detected_bit_stream == 0) = -1;
marker_sequence(marker_sequence == 0) = -1;
[correlation, lags] = xcorr(detected_bit_stream, marker_sequence);
correlation = correlation(lags >= 0);
times = 1:length(correlation);
detected_frame_start_points = times(correlation > threshold);
detected_frames = {};
frame_count = 1;

while 1
    if frame_count > length(detected_frame_start_points)
        break;
    end
    
    frame_start = detected_frame_start_points(frame_count) - frame_start_offset_from_marker;
    frame_end = detected_frame_start_points(frame_count) + length(marker_sequence) + frame_end_offset_from_marker - 1;
    if (frame_start > 0) && (frame_end <= length(detected_bit_stream))
        detected_frames{frame_count} = actual_bit_stream(frame_start:frame_end);
    end
    frame_count = frame_count + 1;
end




