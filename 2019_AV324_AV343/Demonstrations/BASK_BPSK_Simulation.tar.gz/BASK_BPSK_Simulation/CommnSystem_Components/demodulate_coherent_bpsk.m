function demodulated_signal = demodulate_coherent_bpsk(modulated_signal, carrier_frequency, carrier_delay_in_samples, bit_time, sampling_frequency)
t = 0:(1/sampling_frequency):((length(modulated_signal) - 1) * (1/sampling_frequency));
local_carrier_signal = cos(2 * pi * carrier_frequency * (t - carrier_delay_in_samples));
demodulated_signal = modulated_signal .* local_carrier_signal;

lowpass_filterlength = 100;
normalized_cutoff = 4 * (1/bit_time) / sampling_frequency; % carrier frequency also plays a part here, should cutoff the harmonics of the carrier
lowpass_filter = firpm(lowpass_filterlength, [0, normalized_cutoff, normalized_cutoff + 0.1, 1], [1, 1, 0, 0]);
demodulated_signal = conv(demodulated_signal, lowpass_filter);

