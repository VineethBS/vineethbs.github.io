sampling_frequency = 1000; % 1 kHz
bit_time = 0.1; % 0.1 secs
num_samples_in_bit_time = sampling_frequency * bit_time;
carrier_frequency = 100; % 100 Hz

