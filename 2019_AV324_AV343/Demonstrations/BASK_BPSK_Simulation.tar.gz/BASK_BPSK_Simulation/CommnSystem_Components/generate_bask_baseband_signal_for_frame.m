function baseband_signal = generate_bask_baseband_signal_for_frame(frame, upsample_rate, amplitude)
baseband_signal = repmat(frame, upsample_rate, 1);
baseband_signal = amplitude * baseband_signal(:)';
