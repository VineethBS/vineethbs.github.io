function frame = generate_frame_of_bits(probability_of_one, frame_length, frame_header)

random_bits = rand(1, frame_length) <= probability_of_one;
frame = [frame_header, random_bits];