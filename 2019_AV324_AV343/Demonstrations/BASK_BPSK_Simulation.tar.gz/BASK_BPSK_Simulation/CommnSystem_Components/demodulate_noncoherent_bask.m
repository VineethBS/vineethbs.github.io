function demodulated_signal = demodulate_noncoherent_bask(modulated_signal, bit_time, sampling_frequency)

rectified_signal = abs(modulated_signal);
lowpass_filterlength = 100;
normalized_cutoff = 4 * (1/bit_time) / sampling_frequency; % carrier frequency also plays a part here, should cutoff the harmonics of the carrier
lowpass_filter = firpm(lowpass_filterlength, [0, normalized_cutoff, normalized_cutoff + 0.1, 1], [1, 1, 0, 0]);
demodulated_signal = conv(rectified_signal, lowpass_filter);
