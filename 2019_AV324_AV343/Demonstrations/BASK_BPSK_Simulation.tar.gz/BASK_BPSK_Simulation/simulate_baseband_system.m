%% Simulation of a baseband system

addpath CommnSystem_Components/

%% Global system parameters
sampling_frequency = 1000; % 1 kHz
bit_time = 0.1; % 0.1 secs
num_samples_in_bit_time = sampling_frequency * bit_time;
carrier_frequency = 100; % 100 Hz

%% Generate a sequence of frames - each frame containing a header for frame recovery and timing synchronization
num_frames = 10;
num_databits_in_frame = 10;
prob_one = 0.5;

baseband_signal = [];
barker_sequence = [1 1 1 1 1 0 0 1 1 0 1 0 1];
header = [[1,0,1,0,1,0,1,0,1,0], barker_sequence];
generated_frames = {};

for i = 1:num_frames
    generated_frames{i} = generate_frame_of_bits(prob_one, num_databits_in_frame, header);
    baseband_signal = [baseband_signal, generate_bpsk_baseband_signal_for_frame(generated_frames{i}, num_samples_in_bit_time, 1)];
    baseband_signal = [baseband_signal, generate_gap_between_frames(50, num_samples_in_bit_time)];
end

%% Simulate filtering of the signal by the channel
channel_output = pass_through_baseband_channel(baseband_signal, 1, 1, sampling_frequency, 100);
channel_output = add_gaussian_noise(channel_output, 2);

%% Receive the channel output and filter it using the front end filter
rx_filter_output = rx_frontend_filter_baseband(channel_output, 1, 1, sampling_frequency, 100);
eyediagram(rx_filter_output, num_samples_in_bit_time * 2);

%% Use a matched filter
matched_filter_output = matched_filter_rectangular(rx_filter_output, num_samples_in_bit_time);
eyediagram(matched_filter_output, num_samples_in_bit_time * 2);

%% Use early late sampling for timing recovery, then detect the bits
[samples, sampling_times] = early_late_sampler(matched_filter_output, sampling_frequency, bit_time, floor(num_samples_in_bit_time/2), 10, 20, 0);
detected_bit_stream = thresholder(samples, 0);

%% Do recovery of the frames
detected_frames = frame_recovery(detected_bit_stream, barker_sequence, 12, 10, 50);

%% Look at the signals if needed
figure;
hold on;
plot(baseband_signal + 4, 'r');
plot(demodulated_signal + 2, 'k');
plot(matched_filter_output, 'b');
stem(sampling_times, samples);
hold off;

%% How many frames have we received correctly?
for i = 1:length(generated_frames)
    if i > length(detected_frames)
        fprintf(1, '%u-th frame missed\n', i);
        continue;
    end
    if sum(generated_frames{i} == detected_frames{i}) < length(generated_frames{i})
        fprintf(1, 'Bit error in %u-th frame; %u bits in error\n', i, length(generated_frames{i}) - sum(generated_frames{i} == detected_frames{i}));
    end
end
