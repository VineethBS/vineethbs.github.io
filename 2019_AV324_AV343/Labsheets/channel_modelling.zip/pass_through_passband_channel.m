function output = pass_through_passband_channel(input, attenuation, cutoff_frequency_1, cutoff_frequency_2, sampling_frequency, propagation_delay_samples)

transition_width = 0.1;
normalized_cutoff_frequency_1 = 2 * cutoff_frequency_1 / sampling_frequency;
normalized_cutoff_frequency_2 = 2 * cutoff_frequency_2 / sampling_frequency;
stopband_1 = normalized_cutoff_frequency_1 - transition_width;
stopband_2 = normalized_cutoff_frequency_2 + transition_width;

channel_bandpassfilter = firpm(propagation_delay_samples * 2, [0, stopband_1, normalized_cutoff_frequency_1, ...
    normalized_cutoff_frequency_2, stopband_2, 1], [0 0 1 1 0 0]);
output = attenuation * conv(input, channel_bandpassfilter);
