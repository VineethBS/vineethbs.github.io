function output = pass_through_baseband_channel(input, attenuation, cutoff_frequency, sampling_frequency, propagation_delay_samples)

transition_width = 0.1;
normalized_cutoff_frequency = 2 * cutoff_frequency / sampling_frequency;
stopband_start_frequency = normalized_cutoff_frequency + transition_width;
channel_lowpassfilter = firpm(propagation_delay_samples * 2, [0, normalized_cutoff_frequency, stopband_start_frequency, 1], [1 1 0 0]);
output = attenuation * conv(input, channel_lowpassfilter);
