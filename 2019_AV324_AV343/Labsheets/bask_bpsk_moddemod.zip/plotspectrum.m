function plotspectrum(x, Fs, varargin)
% Plots the spectrum of a signal x (x[n]) which is obtained by
% sampling a continuous time domain signal x(t) at sampling
% frequency Fs

N = numel(x);
X = fft(x);

L = floor(N/2);
X = X(1:L);
dF = Fs/N;
f = 0:(L-1);
f = f * dF;

figure;
plot(f, abs(X)/N);
if isempty(varargin)
    title('Spectrum of x');
else
    title(varargin{1});
end
xlabel('Frequency');
ylabel('Magnitude');
