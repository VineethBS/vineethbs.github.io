function modulated_signal = modulate_baseband_signal(baseband_signal, carrier_frequency, carrier_delay_in_samples, sampling_frequency)
t = 0:(1/sampling_frequency):((length(baseband_signal) - 1) * (1/sampling_frequency));
carrier_signal = cos(2 * pi * carrier_frequency * (t - carrier_delay_in_samples));
modulated_signal = carrier_signal .* baseband_signal;

