function output = pass_through_ideal_channel(input, attenuation, propagation_delay_samples)
output = attenuation * [zeros(1, propagation_delay_samples), input];
