function baseband_gap_between_frames = generate_gap_between_frames(poisson_rate, upsample_rate)
baseband_gap_between_frames = zeros(1, poissrnd(poisson_rate));
baseband_gap_between_frames = repmat(baseband_gap_between_frames, upsample_rate, 1);
baseband_gap_between_frames = baseband_gap_between_frames(:)';