function output = add_gaussian_noise(input, variance)
output = input + randn(1, length(input)) * sqrt(variance);
