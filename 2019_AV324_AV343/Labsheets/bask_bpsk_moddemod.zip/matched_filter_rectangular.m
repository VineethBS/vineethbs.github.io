function output = matched_filter_rectangular(input, num_samples_in_bit)
matched_filter_response = ones(1, num_samples_in_bit);
output = 1/num_samples_in_bit * conv(input, matched_filter_response);
