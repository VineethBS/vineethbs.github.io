function baseband_signal = generate_bpsk_baseband_signal_for_frame(frame, upsample_rate, amplitude)
frame(frame == 0) = -1;
baseband_signal = repmat(frame, upsample_rate, 1);
baseband_signal = amplitude * baseband_signal(:)';
