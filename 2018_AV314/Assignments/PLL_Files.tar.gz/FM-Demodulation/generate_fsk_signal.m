%% Sampling and time vector
max_t = 0.1;
fs = 80000;
t = 0:(1/fs):max_t;
num_samples = fs * max_t;

%% A random input sequence of bits
num_bits = 8;
bit_sequence = [1,-1,1,-1,1,1,1,-1];
m = conv(upsample(bit_sequence, num_samples / num_bits), ones(1, num_samples / num_bits));
m = m(1:length(t));

%% FSK signal
kf = 100;
integrated_m = cumsum(m) * 1/fs;
fc = 5000;
Ac = 1;
modulated_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

plot(t, modulated_signal);
plotspectrum(modulated_signal, fs);
pause;

fm_signal = timeseries(modulated_signal(:), t);