sampling_frequency = 80000;

f_freerunning = 5000;

% K = 2 pi Km Kv

% Can we use a type I PLL
K = 5000 * 5000;
a = 8000;
Kv = 5000;
Km = 5000 / 2 /pi;
num_coeff = [1];
denom_coeff = [1, a];

% % If we use a type II PLL
% % PLL parameters
% K = 8000;
% a = 25000/8;
% Kv = 2000;
% Km = 2/pi;
% num_coeff = [1, a];
% denom_coeff = [1, 0];
