sampling_frequency = 80000;
input_frequency = 5500;
input_phasedeg = 0;
% input_phasedeg = 120;

f_freerunning = 5000;

% K = 2 pi Km Kv

% PLL parameters
K = 8000;
a = 25000/8;
Kv = 2000;
Km = 2/pi;
num_coeff = [1, a];
denom_coeff = [1, 0];
