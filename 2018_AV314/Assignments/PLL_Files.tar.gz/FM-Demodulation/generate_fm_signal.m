%% Sampling and time vector
fs = 80000;
t = 0:(1/fs):0.1;

%% Input signal
c = [1, 4, 3, 5];
f = [10, 20, 50, 100];
% c = [1];
% f = [100];

m = zeros(1, length(t));

for i = 1:length(c)
    m = m + c(i) * cos(2 * pi * f(i) * t);
end

% View the message signal and its spectrum
plot(t, m);
plotspectrum(m, fs);
pause

%% FM modulation
kf = 20;
integrated_m = cumsum(m) * 1/fs;
fc = 5000;
Ac = 1;
modulated_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

plot(t, modulated_signal);
plotspectrum(modulated_signal, fs);
pause;

fm_signal = timeseries(modulated_signal(:), t);