% Input phase is chosen to be phase difference of pi/4 from the quadrature phase

K = [100, 1000, 2000, 5000];
systems_o1 = {};

for i = 1:length(K)
    systems_o1{end + 1} = tf([K(i)], [1, K(i)]);
    step(systems_o1{end});hold on;
    pause
end
hold off;

K = [16000000, 25000000];
a = [4000, 8000];
systems_o2 = {};
for i = 1:length(K)
    for j = 1:length(a)
        systems_o2{end + 1} = tf([K(i)], [1, a(j), K(i)]);
        step(systems_o2{end});hold on;
        pause
    end
end

