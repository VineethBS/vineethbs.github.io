% Run this before running the simulation

clear all;
sampling_frequency = 80000;
input_frequency = 5000;
input_phasedeg = 0;
% input_phasedeg = 120;

f_freerunning = 5000;

% K = 2 pi Km Kv

% Option 1
K = 2000;
Kv = 1000;
Km = 1/pi;
num_coeff = [1];
denom_coeff = [1];

% % Option 2
% K = 5000 * 5000;
% a = 8000;
% Kv = 5000;
% Km = 5000 / 2 /pi;
% num_coeff = [1];
% denom_coeff = [1, a];
