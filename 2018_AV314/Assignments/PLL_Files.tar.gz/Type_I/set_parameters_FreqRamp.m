% Run this before running the simulation

clear all;
sampling_frequency = 80000;
input_frequency_start = 5000;
% input_frequency_end = 5100;
input_frequency_end = 5500;
end_time = 0.01;

f_freerunning = 5000;

% Loop options
K = 2000;
Kv = 1000;
Km = 1/pi;
num_coeff = [1];
denom_coeff = [1];