clear;

%% Sampling and time vector
fs = 40000;
t = 0:(1/fs):1;

%% Input signal
% c = [1, 4, 3];
% f = [10, 20, 50];
c = [2];
f = [50];

m = zeros(1, length(t));

for i = 1:length(c)
    m = m + c(i) * cos(2 * pi * f(i) * t);
end

% View the message signal and its spectrum
plot(t, m);
title('Message Signal');
plotspectrum(m, fs, 'Message Signal Spectrum');
pause

%% What is being done in this section of the code?
kf = 100; % What is the constant? How does it affect the bandwidth of the FM signal that we generate?
integrated_m = cumsum(m) * 1/fs; % What is being done in this step? Why is it required?
fc = 1000;
Ac = 1;
modulated_signal = Ac * cos(2 * pi * fc * t + 2 * pi * kf * integrated_m);

plot(t, modulated_signal);
title('Modulated Signal');
plotspectrum(modulated_signal, fs, 'Modulated Signal Spectrum');
pause;

%% What is being done in this section of the code?
% The channel is modelled as a bandpass filter
channel_impulseresponse = BPF_impulseresponse(500, 1500);
channel_output = conv(modulated_signal, channel_impulseresponse);
% Before you plot this and see, do you think the FM modulated signal will pass through this channel? Justify your
% conclusion
plotspectrum(channel_output, fs, 'Channel Output Spectrum');
pause;

%% What is being done in this section of the code?
% Design a BPF filter for the frontend of the filter here. Use the BPF_impulseresponse file.
rx_bpf_output = channel_output; % this is a bypass - use the output of the filter here.

% Limiter % If bypass is required put limiter_output = rx_bpf_output;

limiter_output = sign(rx_bpf_output);
% plot(limiter_output);
limiter_bpf = BPF_impulseresponse(500, 1500); % why are the pass band edge frequencies chosen like this
plotspectrum(limiter_bpf, fs, 'Limiter BPF response');
limiter_output = conv(limiter_output, limiter_bpf);
% plot(limiter_output);
% pause;

% Differentiate the limiter output
differentiator_output = diff(limiter_output);
plot(differentiator_output);
title('Output of differentiator');
pause;

% Envelope detect
% Half wave rectification
rectifier_output = differentiator_output .* (differentiator_output >= 0);
envelope_lpf = LPF_impulseresponse(max(f));
envelope_output = conv(rectifier_output, envelope_lpf);
envelope_output = envelope_output - mean(envelope_output);
plot(envelope_output);
title('Envelope detector output');
plotspectrum(envelope_output, fs, 'Envelope detector output');

