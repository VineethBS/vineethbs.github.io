function ht = HPF_impulseresponse(fc)

fs = 40000;
fsby2 = fs/2;
l = 300;

fcl = (fc - 100)/ fsby2;
fc = fc/fsby2;
ht = firpm(l, [0, fcl, fc, 1], [0, 0, 1, 1]);

