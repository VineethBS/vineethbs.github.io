clear;

sampling_frequency = 1000;
t = 0:(1/sampling_frequency):10;

m = zeros(1, 100);
m(1:2:end) = 1;
m = upsample(m, 100);
m = conv(m, ones(1, 100));

c = sin(2 * pi * 100 * t);
Vi = m(1:length(t)) .* c;

unknown_attenuation = 0.1;
Vi = unknown_attenuation * Vi;

Vi = timeseries(Vi, t);
Vref = 1;
aGm = 1;
moving_average_N = 200;
moving_average_filter = 1/moving_average_N * ones(1, moving_average_N);
initial_state = 1/moving_average_N * ones(1, moving_average_N - 1);

