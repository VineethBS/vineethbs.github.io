function plotspectrum(x)
Fs = 40000;
% Plots the spectrum of a signal x (x[n]) which is obtained by
% sampling a continuous time domain signal x(t) at sampling
% frequency Fs

N = numel(x);
X = fft(x);

L = floor(N/2);
X = X(1:L);
dF = Fs/N;
f = 0:(L-1);
f = f * dF;

figure;
plot(f, abs(X));
title('Spectrum of x');
xlabel('Frequency');
ylabel('Magnitude');