function effective_h = receiverfunction(gain_vector)

fs = 40000;
fsby2 = fs/2;
flen = 200;

% Design the LPF and BPFs
h = {};
h{1} = fir2(flen, [0, 1000/fsby2, 1100/fsby2, 1], [1, 1, 0, 0]);
for i = 2:10
    fbpl1 = ((i - 1)*1000 - 100)/fsby2;
    fbpl2 = (i - 1)*1000/fsby2;
    fbpr1 = i * 1000/fsby2;
    fbpr2 = (i * 1000 + 100)/fsby2;
    h{i} = fir2(flen, [0, fbpl1, fbpl2 , fbpr1, fbpr2, 1], [0, 0, 1, 1, 0, 0]);
end

effective_h = zeros(1, flen + 1);
for i = 1:10
    effective_h = effective_h + gain_vector(i) * h{i};
end
