% Make a baseband channel of my choice
gain = [1, 2, 3, 2.5, 0.5];
channel_impulseresponse = channelsimulator(10000, gain);

% Plot the spectrum and observe
plotspectrum(channel_impulseresponse);
pause

% Design a filter response to undo the effect of the channel
% Freq          Gain          1/Gain
% 0             1             1
% 2500          2             0.5
% 5000          3             0.33
% 7500          2.5           0.4 
% 10000         0.5           2

% But we have bands of 1kHz each in the equalizer
% Freq          Gain         
% 0-1000        1
% 1000-2000     0.5
% 2000-3000     0.5
% 3000-4000     0.33
% 4000-5000     0.33
% 5000-6000     0.33
% 6000-7000     0.4
% 7000-8000     0.4
% 8000-9000     1 
% 9000-10000    2

% Obtain a receiver impulse response
hrx = receiverfunction([1, 0.5, 0.5, 0.33, 0.33, 0.33, 0.4, 0.4, 1, 1]);
% Observe the receiver filter's spectrum
plotspectrum(hrx);
pause;

% Check whether the combined effect of the channel and this receiver filter has all-pass nature?
heff = conv(channel_impulseresponse, hrx);
plotspectrum(heff);

% Try tuning the gain for the receiver function