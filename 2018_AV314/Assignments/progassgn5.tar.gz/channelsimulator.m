function channel_response = channelsimulator(fc, gain)

if (fc < 5000) || (fc > 10000)
    channel_response = 0;
    return;
end
fsby2 = 20000;

fc = fc/fsby2;

freqs = [0, fc/4, fc/2, 3*fc/4, fc];
channel_response = fir2(100, [freqs, 1], [gain, 0]);


