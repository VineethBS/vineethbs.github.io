%% Demonstration of the superheterodyne receiver

%% Sampling and time vector
fs = 40000;
t = 0:(1/fs):1;

%% Input signal
% Limit maximum frequency to be 100
c = [1, 4, 3, 5];
f = [10, 20, 50, 100];
% c = [1];
% f = [50];

m = zeros(1, length(t));

for i = 1:length(c)
    m = m + c(i) * cos(2 * pi * f(i) * t);
end

% View the message signal and its spectrum
plot(t, m);
plotspectrum(m, fs, 'Spectrum of the message signal');
pause

%% Simulation of multiple AM stations
fcs = [2000, 2400, 2800, 3200, 3600, 3900];

modulated_signal = zeros(1, length(t));

% What is the objective of the following for loop?
for i = 1:length(fcs)
    fc = fcs(i);
    modulated_signal = modulated_signal + sum(abs(c)) * cos(2*pi*fc*t) + (-1)^i * m .* cos(2*pi*fc*t);
end

plotspectrum(modulated_signal, fs, 'Spectrum of the modulated signal');
pause;

%% What is done in this section of code?
tuned_channel_frequency = 2400;
station_bandwidth = 400;
channel_left_freq = tuned_channel_frequency - station_bandwidth/2;
channel_right_freq = tuned_channel_frequency + station_bandwidth/2;

% channel_bpf = BPF_impulseresponse_slow(channel_left_freq, channel_right_freq);
channel_bpf = BPF_impulseresponse_fast(channel_left_freq, channel_right_freq);
tuned_channel_output = conv(channel_bpf, modulated_signal);

plotspectrum(tuned_channel_output, fs, 'Spectrum of the channel output');

%% What is done in this section of code?
if_frequency = 1000;
lo_frequency = tuned_channel_frequency + if_frequency;

t_rx = (0:(length(tuned_channel_output) - 1)) / fs;
lo = cos(2 * pi * lo_frequency * t_rx);

if_mixed_signal = tuned_channel_output .* lo;
if_filter = BPF_impulseresponse_fast(if_frequency - station_bandwidth/2, if_frequency + station_bandwidth/2);
if_output = conv(if_filter, if_mixed_signal);

plotspectrum(if_output, fs, 'IF output spectrum');

%% What is done in this section of code?
rectified_output = if_output .* (if_output >= 0);
rectifier_lpf = LPF_impulseresponse(max(f));
output = conv(rectified_output, rectifier_lpf);
output = output - mean(output);

plot(output, 'r');
hold on;
plot(m, 'b');
pause;
