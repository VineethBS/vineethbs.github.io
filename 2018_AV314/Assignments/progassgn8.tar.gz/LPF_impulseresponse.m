function ht = LPF_impulseresponse(fc)

fs = 40000;
fsby2 = fs/2;
l = 300;

fcr = (fc + 100)/ fsby2;
fc = fc/fsby2;
ht = firpm(l, [0, fc, fcr, 1], [1, 1, 0, 0]);

