function ht = BPF_impulseresponse_fast(fb1, fb2)

fs = 40000;
fsby2 = fs/2;
l = 500;

fb1l = (fb1 - 100)/ fsby2;
fb2r = (fb2 + 100)/ fsby2;
fb1 = fb1/ fsby2;
fb2 = fb2/ fsby2;
ht = firpm(l, [0, fb1l, fb1, fb2, fb2r, 1], [0, 0, 1, 1, 0, 0]);

