iq_sampling_frequency = 2048000;
sampling_frequency = 450 * iq_sampling_frequency;
center_freq = 100000000;
t = 0:1/sampling_frequency:5000/center_freq;

figure(1);
hold on;
xlabel('Time');
ylabel('Noise amplitude');

noise = loadFile('Noise/noise_20.wav');
x = passband_signal(noise, iq_sampling_frequency, sampling_frequency, center_freq, t');
plot(t, x, 'r');
fprintf('Average %.2f, Mean square %.2f\n', mean(x), var(x));
pause;

% noise = loadFile('Noise/noise_10.wav');
% x = passband_signal(noise, iq_sampling_frequency, sampling_frequency, center_freq, t');
% plot(t, x, 'b');
% fprintf('Average %.2f, Mean square %.2f\n', mean(x), var(x));
% pause;
% 
% noise = loadFile('Noise/noise_31.wav');
% x = passband_signal(noise, iq_sampling_frequency, sampling_frequency, center_freq, t');
% plot(t, x, 'g');
% fprintf('Average %.2f, Mean square %.2f\n', mean(x), var(x));
% pause;
% 
% noise = loadFile('Noise/noise_56.wav');
% x = passband_signal(noise, iq_sampling_frequency, sampling_frequency, center_freq, t');
% plot(t, x, 'm');
% fprintf('Average %.2f, Mean square %.2f\n', mean(x), var(x));
