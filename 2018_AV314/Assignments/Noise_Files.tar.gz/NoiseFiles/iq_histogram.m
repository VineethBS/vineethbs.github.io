center_freq = 100000000;
t = 0:1/(10*center_freq):5000/center_freq;

num_files = 3000;
times = [1, 100, 250, 500, 1000];
i_at_times = zeros(num_files, length(times));
q_at_times = zeros(num_files, length(times));

for f = 1:num_files
    noise = loadFile(sprintf('Noise/noise_%u.wav',f));
    i = real(noise);
    q = imag(noise);
    for j = 1:length(times)
        i_at_times(f, j) = i(times(j));
        q_at_times(f, j) = q(times(j));
    end
end


