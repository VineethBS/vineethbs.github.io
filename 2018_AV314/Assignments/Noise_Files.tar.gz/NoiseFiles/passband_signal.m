function x = passband_signal(y, iq_sampling_frequency, sampling_frequency, center_freq, t)

% y is a complex baseband signal but sampled at iq_sampling_frequency; we need to change the sampling frequency to
% sampling_frequency
y = resample(y, sampling_frequency, iq_sampling_frequency);
x = 2 * real( y(1:length(t)) .* exp(1i * 2 * pi * center_freq * t));

