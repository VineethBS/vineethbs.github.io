from Simulator import *
from Input import *
from Filter import *
from Output import *
from Metrics import *

# Setup the parameters in your workflow
v = 1
delta_t = 0.001
x0 = 0
sigmasq = 1
input_data_file = "inputdata_file_experiment_1.csv"
infile_type = "csv"
output_data_file = "outputdata_file_experiment_1.csv"
outfile_type = "csv"
metrics_type = "mse"
alpha = 0.1

# Setup the components in your workflow or system
sim = Simulator(v, delta_t, x0, sigmasq)
inp = Input(infile_type, input_data_file)
metric_computation = Metrics(metrics_type)
outp = Output(outfile_type, output_data_file)
datafilter = Filter(alpha)

# Generate some test data
sim.run_simulator(input_data_file, number_of_times)
# A workflow which processes the data in blocks
data = inp.get_input()
datafilter.initialize_y(data[0]) # depends on the data type here
datafilter.process_multiple_data_points(data[1:])
outp.produce_output()

# A workflow which processes the data one at a time - good for interactive tuning, debugging etc
for i in range(?):
	current_data = inp.get_one_input()
	datafilter.process_one_data_point()
	... 




