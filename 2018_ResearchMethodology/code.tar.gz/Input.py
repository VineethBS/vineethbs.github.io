import numpy as np

class Input:
    def __init__(self, type_of_input, filename):
        self.type_of_input = type_of_input
        self.filename = filename

    def get_input(self):
        if self.type_of_input == "csv":
            pass
        elif self.type_of_input == "excel":
            pass
        # return - what should be returned?
    def get_one_input(self):
        if self.type_of_input == "csv":
            pass
        elif self.type_of_input == "excel":
            pass
        # return - what should be returned?
        
        
# How to test this code?        

