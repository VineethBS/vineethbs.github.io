import numpy as np

class Simulator:
    def __init__(self, v, delta_t, x0, sigmasq):
        self.v = v
        self.delta_t = delta_t
        self.sigmasq = sigmasq
        self.x = x0
        self.times = []
        self.dx = []
        self.actual_x = []
        
    def simulate(self, number_of_times):
        time = 0
        for i in range(number_of_times):
            self.times = self.times.append(time)
            self.dx = self.dx.append(self.x + np.random.randn() * sigmasq)
            self.actual_x = self.append(self.x)
            
            self.x = self.x + self.v * self.delta_t

    def file_output(self, output_filename):
        pass

    def run_simulator(self, output_filename, number_of_times):
        self.simulate(number_of_times)
        self.file_output(output_filename)
    
# How to test this module?

