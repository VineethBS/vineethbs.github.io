import numpy as np

class Output:
    def __init__(self, type_of_output, filename):
        self.type_of_output = type_of_output
        self.filename = filename

    def produce_output(self, t, y):
        if self.type_of_output == "csv":
            np.savetxt(self.filename, [t, y], delimiter=",")
        elif self.type_of_output == "excel":
            pass
        elif self.type_of_output == "fig":
            pass

o = Output("csv", "temp.csv")
o.produce_output([0,1],[1,2])
        
