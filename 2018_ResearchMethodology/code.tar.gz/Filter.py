import numpy as np

class Filter:
    def __init__(self, alpha):
        self.alpha = alpha
        self.y = 0;

    def initialize_y(self, d):
        self.y = d
        
    def process_one_data_point(self, d):
        self.y = (self.y + 0.001) * (1 - self.alpha) + self.alpha * d
        print self.y
    
    def process_multiple_data_points(self, d):
        for i in range(len(d)):
            self.process_one_data_point(d[i])

    def file_output(self):
        do something for writing y to a file
        
f = Filter(0.1)
d = [0.1, 0.2, 0.3]
f.initialize_y(d[0])
f.process_multiple_data_points(d[1:3])


