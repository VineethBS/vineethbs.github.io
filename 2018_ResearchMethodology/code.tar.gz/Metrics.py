import numpy as np

class Metrics:
	def __init__(self, metric_type):
		self.metric_type = metric_type
		
	def get_ground_truth(self, ground_truthfile):
		pass
		# what to return from this?
	def get_output_data(self, output_file):
		pass
		# what to return from this?
		
	def compute_metric(self, ground_truthfile, output_file):
		truth = self.get_ground_truth(ground_truthfile)
		data = self.get_output_date(output_file)
		
		if self.metric_type = "mse":
			self.compute_mse(truth, data)
		elif self.metric_type = "sse":
			pass
		elif self.metric_type = "sae":
			pass
			
	def compute_mse(self, truth, data):
		pass
		
# How to test this module?

